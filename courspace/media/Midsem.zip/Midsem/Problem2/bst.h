#include <iostream>
using namespace std;

class BST{
    struct BSTNode
    {
        int data;
        BSTNode * left;
        BSTNode * right;
        BSTNode(int val):data(val),left(NULL),right(NULL){}
    };

    BSTNode* root;
    void freeMemory(BSTNode*);
    void insertLeaf(BSTNode* , int);
    BSTNode* find(BSTNode*, int);

    void printpre(BSTNode*);
    void printin(BSTNode*);
    void printpos(BSTNode*);

public:
    BST();
    ~BST();

    BSTNode* search(int);
    void insert(int);

    void printpre();
    void printin();
    void printpos(); 

    void swapNode(int,int);
    
    void correctBST();
};
