#include <iostream>
#include "bst.h"

BST::BST():root(NULL){}

// --------------------------------------

BST::~BST(){
    freeMemory(root);
}

void BST::freeMemory(BST::BSTNode* node){
    if(node==NULL) return;
    freeMemory(node->left);
    freeMemory(node->right);
    delete node;
}
// --------------------------------------

typename BST::BSTNode* BST::find(BSTNode* curr, int val) {
	if(curr == NULL)
		return NULL;
	else{
		int curr_value = curr->data;
		if(curr_value > val)
			return find(curr->left, val);
		else if(curr_value < val)
			return find(curr->right,val);
		else
			return curr;
	}
}

typename BST::BSTNode* BST::search(int val){
	return find(root,val);
}

// --------------------------------------

void BST::insertLeaf(BSTNode* leaf , int val){
	BSTNode* curr = new BSTNode(val);
	if(leaf == NULL)
		root = curr;
	
	else{
		int leafVal = leaf->data;
		if(leafVal > val)
			leaf->left = curr;
		else if(leafVal < val)
			leaf->right = curr;
	}
}

void BST::insert(int val){
    BSTNode *temp,*prev;
    temp = prev = root;
    while(temp)
    {
        prev = temp;
        if (temp->data < val)
            temp = temp->right;
        else if(temp->data > val)
            temp = temp->left;
    }
    insertLeaf(prev,val);
}

// --------------------------------------

void BST::printpre(BSTNode* root) {
    if (root == NULL) return;
    cout << root->data << " ";
    printpre(root->left);
    printpre(root->right);
}

void BST::printpre(){
    printpre(root);
    std::cout << std::endl;
}

// --------------------------------------

void BST::printin(BSTNode* root){
    if (root == NULL)
        return;
    printin(root->left);
    std::cout << root->data << " ";
    printin(root->right);
}


void BST::printin(){
    printin(root);
    std::cout << std::endl;
}

// --------------------------------------

void BST::printpos(BSTNode* root){
    if (root == NULL)
        return;
    printpos(root->left);
    printpos(root->right);
    std::cout << root->data << " ";
}


void BST::printpos(){
    printpos(root);
    std::cout << std::endl;
}

// --------------------------------------

void BST::swapNode(int val1, int val2){
	BSTNode* n1 = search(val1);
	BSTNode* n2 = search(val2);

	if(n1 == NULL || n2 == NULL) return;

	n1->data = val2;
	n2->data = val1;
	
	return;
}

// --------------------------------------