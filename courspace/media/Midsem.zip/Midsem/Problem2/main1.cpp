#include "bst.h"
#include <stdlib.h>

using namespace std;

int main(){
	srand(time(NULL));
	
	int n;
	cin >> n;
	BST bst;

	for(int i=0;i<n;i++) {
		int x; cin>>x;
		bst.insert(x);
	}

	int T = 1;

	while(T--){
		int r1 = (rand()%n) + 1;
		int r2 = (rand()%n) + 1;

		bst.swapNode(r1, r2);

		bst.correctBST();

		bst.printpos();
		bst.printpre();
	}
	
}