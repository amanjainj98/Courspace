#include "bst.h"

void BST::correctBST(){

	return;
}