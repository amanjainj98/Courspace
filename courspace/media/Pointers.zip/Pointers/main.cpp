#include "String.h"

int main(){
	String a;			
	a.print();

	String b("hello");
	b.print();

	String c(b);
	c.print();

	String d("ahifekfkbf");
	d.print();

	String e(d);
	e.print();
	d.print();
}